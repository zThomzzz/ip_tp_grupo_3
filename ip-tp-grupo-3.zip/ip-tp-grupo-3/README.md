README – Visualizador de Algoritmos de Ordenamiento
Integrante del equipo

Marcos Orieta
Joaquin Latronico
Thomas Magallan

Descripción del proyecto

Este proyecto implementa un visualizador paso a paso para tres algoritmos de ordenamiento:

Bubble Sort

Insertion Sort

Selection Sort

El visualizador fue provisto, y la consigna consistía en implementar las funciones init() y step() para que cada algoritmo ejecutara un solo paso por vez, permitiendo ver cada comparación e intercambio en tiempo real.

Estructura del proyecto
/algorithms/
   bubble.py
   insertion.py
   selection.py
index.html
visualizer.js
README.md

Notas de implementación

La cátedra provee un visualizador que llama:

init(vals) → para iniciar las variables de estado

step() → para ejecutar exactamente un micro-paso del algoritmo

Por eso, todos los algoritmos se programaron usando variables globales (i, j, etc.) para mantener el estado entre llamadas sucesivas.

Bubble Sort

Decisiones importantes:

i representa la pasada externa (cuántos elementos ya están ordenados al final).

j recorre la lista comparando pares adyacentes.

Se usa la condición j == n - i - 2 para detectar el final de una pasada.

Cada step() hace solo una comparación, y si corresponde, un swap.

Dificultad principal:
Comprender por qué la condición correcta era n - i - 2, ya que en Bubble la última comparación válida es entre items[n-i-2] y items[n-i-1].

Insertion Sort

Decisiones:

i apunta al elemento que queremos insertar.

j comienza como None para indicar que recién se inicia una nueva inserción.

Al comienza de cada inserción se hace un highlight sin swap.

Mientras items[j-1] > items[j], se hace un swap por paso.

Cuando ya no hay que mover más, se avanza i y se reinicia j=None.

Dificultad principal:
Comprender que step() no puede usar bucles (while) para insertar, sino que debe hacer solo un desplazamiento por vez, lo cual obliga a separar claramente los momentos:
iniciar una inserción, desplazar, o finalizarla.

Selection Sort

Decisiones:

i marca la posición actual donde debe quedar el menor elemento.

j recorre el segmento no ordenado buscando el mínimo.

Se mantiene una variable min_index (global) que guarda dónde está el menor encontrado.

Cuando j llega al final, se hace un único swap entre i y min_index.

Después se avanza al siguiente i.

Dificultad principal:
Comprender que Selection hace la búsqueda completa del mínimo antes de intercambiar, pero como el visualizador pide un paso por vez, esa búsqueda debe hacerse comparando un solo par (min_index, j) en cada llamada a step().

Cómo ejecutar el visualizador?

Abrir una terminal en la carpeta raíz del proyecto.

Ejecutar:

python -m http.server


Abrir el navegador en:

http://localhost:8000


Seleccionar el algoritmo y presionar "Step" para avanzar paso por paso.
Los tres algoritmos se implementaron siguiendo las restricciones del visualizador y funcionan paso por paso mostrando:

Comparaciones
Intercambios
Avances de índices